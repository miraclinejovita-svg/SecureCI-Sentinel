-- Initial database bootstrap for SecureCI Sentinel.
-- Table creation is normally handled by Alembic migrations (see backend/alembic);
-- this file just ensures required extensions exist on first container start.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
