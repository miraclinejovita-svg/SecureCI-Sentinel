from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, HttpUrl

from app.models.project import ProjectStatus


class ProjectBase(BaseModel):
    name: str
    repo_url: HttpUrl
    default_branch: str = "main"


class ProjectCreate(ProjectBase):
    pass


class ProjectRead(ProjectBase):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    owner_id: UUID
    status: ProjectStatus
    created_at: datetime
