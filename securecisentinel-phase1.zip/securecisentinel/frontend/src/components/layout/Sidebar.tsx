import { NavLink } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard" },
  { to: "/projects", label: "Projects" },
  { to: "/repositories", label: "Repositories" },
  { to: "/scans", label: "Security Scans" },
  { to: "/pipeline", label: "Pipeline Status" },
  { to: "/vulnerabilities", label: "Vulnerabilities" },
  { to: "/reports", label: "Reports" },
  { to: "/audit-logs", label: "Audit Logs" },
  { to: "/settings", label: "Settings" },
];

export default function Sidebar() {
  return (
    <aside
      style={{
        width: 220,
        background: "var(--bg-panel)",
        borderRight: "1px solid var(--border)",
        padding: "1.5rem 1rem",
        minHeight: "100vh",
      }}
    >
      <div style={{ fontWeight: 700, marginBottom: "2rem", color: "var(--accent)" }}>
        SecureCI Sentinel
      </div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            style={({ isActive }) => ({
              padding: "0.5rem 0.75rem",
              borderRadius: 6,
              textDecoration: "none",
              color: isActive ? "var(--accent)" : "var(--text-muted)",
              background: isActive ? "rgba(34,211,238,0.1)" : "transparent",
              fontSize: 14,
            })}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
