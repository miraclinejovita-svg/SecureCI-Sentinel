import { Navigate, Route, Routes } from "react-router-dom";
import AppLayout from "./components/layout/AppLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import Repositories from "./pages/Repositories";
import SecurityScans from "./pages/SecurityScans";
import PipelineStatus from "./pages/PipelineStatus";
import Reports from "./pages/Reports";
import Vulnerabilities from "./pages/Vulnerabilities";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";
import AuditLogs from "./pages/AuditLogs";

function isAuthenticated() {
  return Boolean(localStorage.getItem("access_token"));
}

function ProtectedRoute({ children }: { children: JSX.Element }) {
  return isAuthenticated() ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Dashboard />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/repositories" element={<Repositories />} />
        <Route path="/scans" element={<SecurityScans />} />
        <Route path="/pipeline" element={<PipelineStatus />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/vulnerabilities" element={<Vulnerabilities />} />
        <Route path="/audit-logs" element={<AuditLogs />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
