export default function SecurityScans() {
  return (
    <div>
      <h1>SecurityScans</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
