export default function Vulnerabilities() {
  return (
    <div>
      <h1>Vulnerabilities</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
