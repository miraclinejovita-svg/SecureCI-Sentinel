const METRICS = [
  { label: "Projects", value: "—" },
  { label: "Critical Vulns", value: "—", color: "var(--critical)" },
  { label: "High", value: "—", color: "var(--high)" },
  { label: "Medium", value: "—", color: "var(--medium)" },
  { label: "Low", value: "—", color: "var(--low)" },
  { label: "Pipeline Success Rate", value: "—" },
];

export default function Dashboard() {
  return (
    <div>
      <h1>Risk Dashboard</h1>
      <p style={{ color: "var(--text-muted)" }}>
        Phase 1 skeleton — metrics will populate once the scan engine (Phase 3+) is wired up.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginTop: 24 }}>
        {METRICS.map((m) => (
          <div
            key={m.label}
            style={{
              background: "var(--bg-panel)",
              border: "1px solid var(--border)",
              borderRadius: 10,
              padding: "1.25rem",
            }}
          >
            <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{m.label}</div>
            <div style={{ fontSize: 28, fontWeight: 700, color: m.color ?? "var(--text-primary)" }}>{m.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
