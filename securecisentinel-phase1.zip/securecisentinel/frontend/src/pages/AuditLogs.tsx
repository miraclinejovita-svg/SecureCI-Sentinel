export default function AuditLogs() {
  return (
    <div>
      <h1>AuditLogs</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
