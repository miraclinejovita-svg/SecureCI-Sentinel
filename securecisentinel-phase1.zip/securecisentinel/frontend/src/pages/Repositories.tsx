export default function Repositories() {
  return (
    <div>
      <h1>Repositories</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
