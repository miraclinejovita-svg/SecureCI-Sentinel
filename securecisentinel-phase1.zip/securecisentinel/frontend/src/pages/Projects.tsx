export default function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
