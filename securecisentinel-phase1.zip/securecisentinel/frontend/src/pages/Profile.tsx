export default function Profile() {
  return (
    <div>
      <h1>Profile</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
