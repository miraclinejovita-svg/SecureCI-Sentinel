export default function PipelineStatus() {
  return (
    <div>
      <h1>PipelineStatus</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
