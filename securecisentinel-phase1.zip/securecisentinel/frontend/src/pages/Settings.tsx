export default function Settings() {
  return (
    <div>
      <h1>Settings</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
