export default function Reports() {
  return (
    <div>
      <h1>Reports</h1>
      <p style={{ color: "var(--text-muted)" }}>Coming in a later phase.</p>
    </div>
  );
}
