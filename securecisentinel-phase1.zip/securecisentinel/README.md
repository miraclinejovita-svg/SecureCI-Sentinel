# SecureCI Sentinel

A DevSecOps Secure CI/CD Pipeline platform that scans applications for security
issues — SAST, DAST, dependency vulnerabilities, secrets, container and IaC
misconfigurations — before deployment, and reports on them through a risk
dashboard.

This README documents **Phase 1: Project Architecture & Foundational Skeleton**.
Scanning engines, the pipeline orchestrator, and full reporting are built in
later phases on top of this foundation.

---

## 1. What's in Phase 1

- Monorepo folder structure for the full platform
- Dockerized PostgreSQL + Redis
- FastAPI backend skeleton with:
  - JWT auth (access + refresh tokens), bcrypt password hashing
  - Role-Based Access Control (Admin, Security Engineer, Developer, Auditor)
  - Async SQLAlchemy models (`User`, `Project`) + Alembic migrations
  - Baseline secure headers, CORS, rate limiting
  - `Project` CRUD endpoints (create/list/get) — scan endpoints come later
- React + TypeScript frontend skeleton with:
  - Login page wired to `/api/v1/auth/login`
  - Protected route shell + sidebar navigation for all 11 dashboard pages
    (most are placeholder stubs for now)
  - Dashboard page with metric-card layout (values populate once scanning exists)
- Nginx reverse proxy in front of frontend + backend
- Initial GitHub Actions workflow: checkout → build → lint → test
  (stages 5–16 of the full pipeline — Semgrep, SonarQube, Trivy, ZAP, etc. —
  are added in later phases)

## 2. Folder structure

```
securecisentinel/
├── frontend/           React + TypeScript SPA (Vite)
│   ├── src/
│   │   ├── pages/          One file per dashboard page
│   │   ├── components/     Layout (sidebar, app shell)
│   │   ├── context/         Auth context
│   │   ├── api/              Axios client
│   │   └── types/            Shared TS types
│   ├── Dockerfile           Multi-stage build → nginx static serve
│   └── nginx.conf
├── backend/             FastAPI application
│   ├── app/
│   │   ├── api/v1/endpoints/  auth.py, projects.py
│   │   ├── core/               config.py, security.py, rbac.py
│   │   ├── db/                  session.py (async SQLAlchemy)
│   │   ├── models/              user.py, project.py
│   │   ├── schemas/             Pydantic request/response models
│   │   └── main.py              App entrypoint
│   ├── alembic/                Migration environment
│   ├── tests/                    Pytest suite
│   ├── requirements.txt
│   └── Dockerfile
├── database/
│   └── init.sql             Extensions bootstrap (uuid-ossp, pgcrypto)
├── docker/nginx/
│   └── nginx.conf           Root reverse proxy config
├── scanner/                  (empty — scan engine wrappers land in Phase 3+)
├── github-actions/           Copy of the CI workflow for reference/docs
├── .github/workflows/ci.yml  Active GitHub Actions workflow
├── reports/                    Generated scan reports land here (gitignored)
├── scripts/                    (empty — helper scripts land in later phases)
├── docs/                        (empty — architecture/threat-model docs land in a later phase)
├── tests/                        (empty — integration/e2e tests land in later phases)
└── docker-compose.yml
```

## 3. Roles (RBAC)

| Role               | Intended permissions (enforced incrementally as features land) |
|---------------------|------------------------------------------------------------------|
| Admin               | Full access: users, projects, settings, all scan data           |
| Security Engineer   | Manage projects, run/review scans, manage vulnerabilities        |
| Developer            | Create projects, view own scans/vulnerabilities, view remediation |
| Auditor               | Read-only access to scans, reports, and audit logs                |

Phase 1 wires the `role` field and `require_roles()` dependency into the
`Project` creation endpoint as a working example; the rest of the matrix is
enforced as each feature is built.

## 4. How to run it

**Prerequisites:** Docker + Docker Compose installed.

```bash
# 1. Clone / cd into the repo
cd securecisentinel

# 2. Create backend env file
cp backend/.env.example backend/.env
# edit backend/.env and set a real SECRET_KEY for anything beyond local dev

# 3. Build and start everything
docker compose up --build
```

Services once running:

| Service   | URL                          |
|-----------|-------------------------------|
| App (via Nginx) | http://localhost              |
| Frontend (direct) | http://localhost:5173      |
| Backend API       | http://localhost:8000      |
| API docs (Swagger) | http://localhost:8000/api/v1/docs |
| Postgres  | localhost:5432 (sentinel/sentinel_pass) |
| Redis     | localhost:6379                |

**First-time setup — create the database schema:**

```bash
docker compose exec backend alembic revision --autogenerate -m "initial schema"
docker compose exec backend alembic upgrade head
```

**Create your first user** via Swagger UI (`/api/v1/docs` → `POST /auth/register`)
or:

```bash
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@sentinel.local","full_name":"Admin User","password":"ChangeMe123!","role":"admin"}'
```

Then log in through the frontend at http://localhost:5173/login.

## 5. How to test it

**Backend unit tests:**

```bash
cd backend
pip install -r requirements.txt
pytest -v
```

**Frontend build/type-check:**

```bash
cd frontend
npm install
npm run build
```

**Manual smoke test:**

```bash
curl http://localhost:8000/health
# {"status":"ok","service":"SecureCI Sentinel","environment":"development"}
```

**CI pipeline:** pushing to `main` or `develop` (or opening a PR against them)
triggers `.github/workflows/ci.yml`, which runs backend lint/test and
frontend build/type-check.

## 6. What's next (Phase 2+)

- Full user management + audit logging
- Repository onboarding (GitHub API integration, clone-to-scan flow)
- Scan orchestration service (Celery + Redis queue) and the `scanner/`
  wrappers for Semgrep, Trivy, Gitleaks, OWASP ZAP, Nmap, Nikto, testssl.sh,
  Syft/CycloneDX SBOM generation
- Vulnerability model with full field set (CVE, CVSS, CWE, OWASP mapping,
  MITRE ATT&CK mapping, remediation) + filtering UI
- Report generation (PDF/JSON/CSV/HTML) with executive summary and charts
- Full 16-stage GitHub Actions pipeline with critical-vuln deployment gating
- Notifications (email, Slack, Teams, webhook)
- docs/: architecture diagram, API docs, DB schema, deployment/dev/security
  guides, STRIDE threat model, OWASP Top 10 + MITRE ATT&CK mapping docs

---

Let me know when you're ready and I'll move on to **Phase 2**.
